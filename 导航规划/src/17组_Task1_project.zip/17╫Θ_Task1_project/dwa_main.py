import os, sys
import math
from vision import Vision
from action import Action
from debug import Debugger
from zss_debug_pb2 import Debug_Msgs
from scipy.interpolate import CubicSpline

import time
import numpy as np
from rrtstar import RRT_star
# from RRTStar_copy import RRT_star
from dwa import DWA
# from dwa_with_predict import DWA

import threading
import concurrent.futures
 
from vision import Vision
from action import Action
from debug import Debugger
from prm import PRM
import time
from rrtstar import RRT_star

if __name__ == '__main__':
    vision = Vision()
    action = Action()
    debugger = Debugger()
    # planner = PRM()
    planner = RRT_star()

    while True:
        # 1. path planning & velocity planning
        start_x, start_y = vision.my_robot.x, vision.my_robot.y
        goal_x, goal_y = -2400, -1500
        path = planner.plan(vision=vision, start_x=start_x, start_y=start_y, end_x=goal_x, end_y=goal_y)
        
        if path is not None:
            path_x_list, path_y_list = list(zip(*path))

            # 3. draw debug msg
            package = Debug_Msgs()
            debugger.draw_points(package, path_x_list, path_y_list)
            debugger.send(package)  # 发送绘制的消息给调试器

            # 2. send command
            action.sendCommand(vx=0, vy=0, vw=0)

            time.sleep(0.1)
